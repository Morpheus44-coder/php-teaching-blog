<?php
    if(isset($_GET["id"])){
        $id = $_GET["id"];
        ?>
        <?php
            include "client/header.php";
        ?>

        <?php
            include "client/nav.php";
        ?>
        
        <div class="container-fluid text-center">    
        <div class="row content">
        <?php
            include "client/left_slider.php";
        ?>
            <div class="col-sm-8 text-left"> 
            <?php
                $sql = "SELECT * FROM posts WHERE id=$id";
                $result = mysqli_query($connect,$sql);
                if($result){
                    foreach($result as $r){
                        $title = $r["title"];
                        $image = $r["image"];
                        $category = $r["category"];
                        $description = $r["description"];
                        ?>
                            <div class="conintare">
                                <h1 class="text-center text-primary">
                                    <?php echo $title ?> 's Post Detial
                                </h1>
                                <img src="admin/backend/upload/<?php echo $image ?>" class="img-responisve img-thumbnail" alt="">
                                <h3>category : <?php echo $category ?> </h3>
                                <p class="text-justify">
                                    <?php echo $description ?>
                                </p>
                            </div>
                        <?php
                    }
                }
            ?>
            
            </div>
            <!-- right side bar -->
            <?php
                include "client/right_side_bar.php";
            ?>
        </div>
        </div>



        <?php
            include "client/footer.php";
        ?>
        <?php
    }else{
        header("location:index.php");
    }
?>

