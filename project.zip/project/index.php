<?php
    include "client/header.php";
?>

<?php
    include "client/nav.php";
?>
  
<div class="container-fluid text-center">    
  <div class="row content">
  <?php
    include "client/left_slider.php";
  ?>
    <div class="col-sm-8 text-left"> 
    <h1 class="text-center text-primary">The Category With 3Latest Post</h1>
      <?php
        $sql = "SELECT * FROM category";
        $data1 = mysqli_query($connect,$sql);
        foreach($data1 as $d1){
          $category = $d1['title'];
          ?>
              <h1>Category : <?php echo $category ?></h1>
              <?php
                  $sql = "SELECT * FROM posts WHERE category='$category' ORDER BY id DESC LIMIT 3 ";
                  $data2 = mysqli_query($connect,$sql);
                  foreach($data2 as $d2){
                    $post_title = $d2["title"];
                    $post_description = $d2["description"];
                    $post_image = $d2["image"];
                    $post_id = $d2["id"];
                    ?>
                      <div class="media">
                      <div class="media-left">
                        <img src="admin/backend/upload/<?php echo $post_image ?>" class="media-object" style="width:60px">
                      </div>
                      <div class="media-body">
                        <h4 class="media-heading"><?php echo $post_title ?></h4>
                        <p><?php echo $post_description ?></p>
                      </div>
                    </div>
                    <?php
                  }
              ?>
          <?php
        }
      ?>
    </div>
    <!-- right side bar -->
    <?php
        include "client/right_side_bar.php";
    ?>
  </div>
</div>



<?php
    include "client/footer.php";
?>