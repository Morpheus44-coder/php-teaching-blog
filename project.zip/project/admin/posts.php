<?php
    include "layout/header.php";
?>
<div class="container-fluid">
  <div class="row content">

    <?php
        include "layout/slide.php";
    ?>

    <div class="col-sm-9">
        <h1 class="text-primary text-center">Admin Posts List</h1>
        <ul class="breadcrumb">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="posts.php">Posts</a></li>
        </ul>
        <br>
        <?php
            if(isset($_GET['information'])){
                $info = $_GET['information'];
                ?>
                    <p class="alert alert-info"><?php echo $info ?></p>
                <?php
            }
        ?>
        <br>
            <a href="post_create.php" class="btn btn-success">Create Posts</a>
        <br>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th>image</th>
                    <th>Update</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $sql = "SELECT * FROM posts ORDER BY id DESC ";
                    $result = mysqli_query($connect,$sql);
                    if(mysqli_num_rows($result)>0){
                        foreach($result as $i=>$r){
                            ?>
                                <tr>
                                    <td><?php echo ++$i ?></td>
                                    <td><?php echo $r["title"] ?></td>
                                    <td><?php echo $r["category"] ?></td>
                                    <td><?php echo $r["description"] ?></td>
                                    <td><img src="backend/upload/<?php echo $r['image'] ?>" class="img-responsive img-thumbnail"  alt=""></td>
                                    <td><a href="backend/post_update.php?id=<?php echo $r["id"] ?>" class="btn btn-warning">Update</a></td>
                                    <td><a href="backend/post_delete.php?id=<?php echo $r["id"] ?>" class="btn btn-danger">Delete</a></td>
                                </tr>
                            <?php
                        }
                    }
                ?>
            </tbody>
        </table>
     </div>
  </div>  
</div>
<?php
    include "layout/footer.php";
?>



