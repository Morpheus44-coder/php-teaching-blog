<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    

<div class="container-fluid">
  <div class="row content">
    <div class="col-md-6 col-md-offset-3 " style="margin-top:130px">
       <div class="panel panel-primary">
            <div class="panel-heading">
                <h3>Admin Login</h3>
            </div>
            <?php
              if(isset($_GET["information"])){
                ?>
                  <p class="alert alert-info"><?php echo $_GET["information"] ?></p>
                <?php
              }
            ?>
            <div class="panel-body">
                <form action="backend/login.php" method="post" class="form">
                    <input type="text" class="form-control" placeholder="Enter Username" name="username" required>
                    <br> 
                    <input type="password" class="form-control" placeholder="Enter Password" name="password" required>
                    <br> 
                    <input type="submit" class="btn btn-primary pull-right" value="Login" name="login">
                </form>
            </div>
       </div>
    </div>
  </div>  
</div>

</body>
</html>

