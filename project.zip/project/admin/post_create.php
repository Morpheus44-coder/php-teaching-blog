<?php
    include "layout/header.php";
?>
<div class="container-fluid">
  <div class="row content">

    <?php
        include "layout/slide.php";
    ?>

    <div class="col-sm-9">
        <h3 class="text-center text-primary">Admin Posts Create</h3>
        <br> <br>
        <ul class="breadcrumb">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="posts.php">Post</a></li>
            <li><a href="post_create.php">Create Posts</a></li>
        </ul>
        <br> 
        <?php
            if(isset($_GET['information'])){
                $info = $_GET['information'];
                ?>
                    <p class="alert alert-info"><?php echo $info ?></p>
                <?php
            }
        ?>
        <br>
       <form action="backend/posts_backend.php" method="POST" class="form" enctype="multipart/form-data">
            <input type="text" class="form-control" name="title" placeholder="Enter Posts Title" required> <br> 
            <select name="category" id="" class="form-control" required>
                <option value="other">Other</option>
                <?php 
                    $sql = "SELECT * FROM category";
                    $result = mysqli_query($connect,$sql);
                    if(mysqli_num_rows($result)){
                        foreach($result as $r){
                            ?>
                                <option value="<?php echo $r["title"] ?>"><?php echo $r["title"] ?></option>
                            <?php
                        }
                    }
                ?>
                
            </select> <br>
            <textarea name="description" class="form-control" id="" placeholder="Enter Your Description" cols="30" rows="10" required ></textarea> <br>
            <input type="file" name="image" required> <br>
            <input type="submit" class="btn btn-primary" value="Create" name="ok">
       </form>
    </div>
  </div>  
</div>
<?php
    include "layout/footer.php";
?>

