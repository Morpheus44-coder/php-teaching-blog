<?php
    include "layout/header.php";
?>
<div class="container-fluid">
  <div class="row content">

    <?php
        include "layout/slide.php";
    ?>
    <h1 class="text-center text-primary">Category List</h1>
    <div class="col-sm-9">
        <ul class="breadcrumb">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="category.php">Category</a></li>
        </ul>
        <br>
                <?php
            if(isset($_GET['information'])){
                $info = $_GET['information'];
                ?>
                    <p class="alert alert-info"><?php echo $info ?></p>
                <?php
            }
        ?>
        <br> 
        <a href="category_create.php" class="btn btn-success">Create Category</a>
        <br> 
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Title</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $sql = "select * from category";
                    $result = mysqli_query($connect,$sql);
                    if(mysqli_num_rows($result)>0){
                        foreach($result as $i=>$r){
                            ?>
                            <tr>
                                <td><?php echo ++$i ?></td>
                                <td><?php echo $r["title"] ?></td>
                                <td><a href="backend/category_delete.php?id=<?php echo $r["id"] ?>" class="btn btn-danger">Delete</a></td>
                            </tr>
                            <?php
                        }
                    }
                ?>
            </tbody>
        </table>
     </div>
  </div>  
</div>
<?php
    include "layout/footer.php";
?>

