<?php
    define("host","localhost");
    define("username","root");
    define("password","");
    define("database","blog");
    $connect  = mysqli_connect(host,username,password,database);
    if(!$connect){
        echo "Database Can not Connect " . mysqli_error();
    }
?>