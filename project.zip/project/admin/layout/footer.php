<footer class="container-fluid">
  <p>Footer Text</p>
</footer>

</body>
</html>