    <div class="col-sm-3 sidenav">
      <h4>KBTC Project</h4>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="../index.php">Go To Website</a></li>
        <li class="active"><a href="index.php">Dashboard</a></li>
        <li><a href="category.php">Category</a></li>
        <li><a href="posts.php">Posts</a></li>
        <li><a href="account.php">Account</a></li>
        <li><a href="#section3">Contact</a></li>
        <li><a href="backend/logout.php">Logout</a></li>
      </ul>
      <br>
    </div>