<?php
    include "layout/header.php";
?>
<div class="container-fluid">
  <div class="row content">

    <?php
        include "layout/slide.php";
    ?>

    <div class="col-sm-9">
        <h3 class="text-center text-primary">Admin Account Create</h3>
        <br> <br>
        <ul class="breadcrumb">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="account.php">Account</a></li>
            <li><a href="account_create.php">Create Account</a></li>
        </ul>
        <br> 
        <?php
            if(isset($_GET['information'])){
                $info = $_GET['information'];
                ?>
                    <p class="alert alert-info"><?php echo $info ?></p>
                <?php
            }
        ?>
        <br>
       <form action="backend/account_backend.php" method="POST" class="form">
            <input type="text" class="form-control" name="username" placeholder="Enter Your User Name" required> <br> 
            <input type="password" class="form-control" name="password" placeholder="Enter Your Password" required> <br>
            <input type="password" class="form-control" name="cpassword" placeholder="Enter Your Confirm Password" required> <br>
            <input type="submit" class="btn btn-primary" value="Create" name="ok">
       </form>
    </div>
  </div>  
</div>
<?php
    include "layout/footer.php";
?>

