<?php
    include "../layout/database.php";
    if(isset($_POST["ok"])){
       $name = htmlspecialchars($_POST["username"]) ;
       $password = htmlspecialchars($_POST["password"]) ;
       $cpassword =htmlspecialchars($_POST["cpassword"])  ;
        if($password != $cpassword){
            header("location:../account_create.php?information=Password and Confrim Password is Not Same.");
        }else{
            $sql = "SELECT * FROM admin WHERE name='$name'";
            $result = mysqli_query($connect,$sql);
            if(mysqli_num_rows($result)>0){
                header("location:../account_create.php?information=Your Account is Already Exits.");
            }else{
                $password = crypt($password,$name);
                $sql = "INSERT INTO admin(name,password) VALUES ('$name','$password')";
                $result = mysqli_query($connect,$sql);
                if($result){
                   header("location:../account.php?information=Account Create Success");
                }else{
                    header("location:../account_create.php?information=Account Create Fail");
                }
            }
           
            
        }
    }else{
        header("location:../account_create.php");
    }
?>