<?php
    include "../layout/database.php";
    if(isset($_POST["ok"])){
       $title = $_POST["title"];
       $category = $_POST["category"];
       $description = $_POST["description"];
       $myfile = $_FILES["image"];
    //    echo $title . "<br>" . $category . "<br>" . $description . "<br>" . $image["name"] . "<br>";
       if($myfile["error"]>0){
           echo "Your File Has Error So We Can't Upload";
       }else{
           if($myfile["type"]=="image/png" || $myfile["type"]=="image/jpg" || $myfile["type"]=="image/jpeg"){
                if($myfile["size"]>300000000){
                    echo "Your File Size is Too Big";
                }else{
                    $ran = rand(0,10000);
                    move_uploaded_file($myfile["tmp_name"],"upload/".$ran."_".$myfile["name"]);
                    // move_uploaded_file($myfile["tmp_name"],"upload/".$myfile["name"]);
                    $image = $ran."_".$myfile["name"];
                   $sql = "INSERT INTO posts(title,category,description,image) VALUES ('$title','$category','$description','$image')";
                   $result = mysqli_query($connect,$sql);
                   if($result){
                       header("location:../posts.php?informtaion='Post Create Sucess'");
                   }
                }
           }else{
                echo "Your File Can not Be Upload";
           }
       }
    }else{
        header("location:../posts.php");
    }
?>