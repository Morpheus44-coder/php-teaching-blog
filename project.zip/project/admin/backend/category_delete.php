<?php
    if(isset($_GET["id"])){
        include "../layout/database.php";
        $id = $_GET["id"];
        $sql = "DELETE FROM category WHERE id='$id'";
        $result = mysqli_query($connect,$sql);
        if($result){
            header("location:../category.php?information='Delete Category is Success'");
        }
    }else{
        header("location:../category.php");
    }
?>