<?php
    if(isset($_GET["id"])){ 
        ?>
        <?php
    include "../layout/header.php";
?>
<div class="container-fluid">
  <div class="row content">

    <?php
        include "../layout/slide.php";
    ?>

    <div class="col-sm-9">
        <h3 class="text-center text-primary">Admin Posts Update</h3>
        <br> <br>
        <ul class="breadcrumb">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="../posts.php">Post</a></li>
            <li><a href="post_update.php">Update Posts</a></li>
        </ul>
        <br> 
        <?php
            if(isset($_GET['information'])){
                $info = $_GET['information'];
                ?>
                    <p class="alert alert-info"><?php echo $info ?></p>
                <?php
            }
        ?>
        <br>
       <form action="post_update_backend.php" method="POST" class="form" enctype="multipart/form-data">
      
       <?php
           $id = $_GET["id"];
           $sql = "SELECT * FROM posts WHERE id='$id'";
           $result = mysqli_query($connect,$sql);
           if(mysqli_num_rows($result)>0){
               foreach($result as $r){
                   ?>
            <input type="hidden" value="<?php echo $r['id'] ?>" name="id">
            <input type="text" class="form-control" value='<?php echo $r['title'] ?>' name="title" placeholder="Enter Posts Title" required> <br> 
            <select name="category" id="" class="form-control" required>
                <option value="<?php echo $r['category'] ?>"><?php echo $r['category'] ?></option>
                <option value="other">Other</option>
                    <?php 
                        $sql = "SELECT * FROM category";
                        $result = mysqli_query($connect,$sql);
                        if(mysqli_num_rows($result)){
                            foreach($result as $rr){
                                ?>
                                    <option value="<?php echo $rr["title"] ?>"><?php echo $rr["title"] ?></option>
                                <?php
                            }
                        }
                    ?>
                
            </select> <br>
            <textarea name="description" class="form-control" id="" placeholder="Enter Your Description" cols="30" rows="10" required ><?php echo $r['description'] ?>
            </textarea> <br>
            <img src="upload/<?php echo $r['image'] ?>" class='img-responsive img-thumbnail' style="with:300px;height:300px" alt="">
            <input type="file" name="image" required> <br>
            <input type="submit" class="btn btn-primary" value="Update" name="ok">
                   <?php
               }
           }
        ?>
            
       </form>
    </div>
  </div>  
</div>
<?php
    include "../layout/footer.php";
?>


        <?php
    }else{
        header("location:../posts.php");
    }
?>