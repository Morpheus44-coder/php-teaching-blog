
<?php
  session_start();
  if(!isset($_SESSION["username"]) || !isset($_SESSION["password"])){
    header("location:login.php?information='Your Must Login First'");
  }
?>
<?php
    if(isset($_GET["id"])){
        include "../layout/database.php";
        $id = $_GET["id"];
        $sql = "SELECT * FROM admin WHERE id='$id'";
        $result = mysqli_query($connect,$sql);
        if(mysqli_num_rows($result)>0){
            ?>
        <!-- header start  -->
        <!DOCTYPE html>
        <html lang="en">
        <head>
        <title>Bootstrap Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style>
            /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
            .row.content {height: 1500px}
            
            /* Set gray background color and 100% height */
            .sidenav {
            background-color: #f1f1f1;
            height: 100%;
            }
            
            /* Set black background color, white text and some padding */
            footer {
            background-color: #555;
            color: white;
            padding: 15px;
            }
            
            /* On small screens, set height to 'auto' for sidenav and grid */
            @media screen and (max-width: 767px) {
            .sidenav {
                height: auto;
                padding: 15px;
            }
            .row.content {height: auto;} 
            }
        </style>
        </head>
        <body>

        <!-- header end -->
        <div class="container-fluid">
        <div class="row content">

        <!-- slider start -->
        <div class="col-sm-3 sidenav">
        <h4>KBTC Project</h4>
        <ul class="nav nav-pills nav-stacked">
            <li class="active"><a href="index.php">Dashboard</a></li>
            <li><a href="category.php">Category</a></li>
            <li><a href="posts.php">Posts</a></li>
            <li><a href="../account.php">Account</a></li>
            <li><a href="#section3">Contact</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
        <br>
        </div>
        <!-- slider end -->

        <div class="col-sm-9">
            <h3 class="text-center text-primary">Admin Account Update</h3>
            <br> <br>
             <?php
                if(isset($_GET['information'])){
                    $info = $_GET['information'];
                    ?>
                    <p class="alert alert-info"><?php echo $info ?></p>
                    <?php
                 }
                ?>
                <br>
            <ul class="breadcrumb">
                <li><a href="../index.php">Dashboard</a></li>
                <li><a href="../account.php">Account</a></li>
                <li><a href="#">Update Account</a></li>
            </ul>
            <br> 
            <br>
            <?php
                foreach($result as $r){
                    ?>
                    <form action="update_account_backend.php" method="POST" class="form">
                        <input type="hidden" name="id" value="<?php echo $r["id"] ?>">
                        <input type="text" class="form-control" value="<?php echo $r["name"] ?>" name="username" placeholder="Enter Your User Name" required> <br> 
                        <input type="password" class="form-control" name="password" placeholder="Enter Your Password" required> <br>
                        <input type="password" class="form-control" name="cpassword" placeholder="Enter Your Confirm Password" required> <br>
                        <input type="submit" class="btn btn-warning" value="Update" name="ok">
                    </form>
                    <?php
                }
            ?>

            </div>
        </div>  
        </div>
        <?php
            include "../layout/footer.php";
        ?>
            <?php
        }
    }else{
        header("location:../index.php");
    }
?>