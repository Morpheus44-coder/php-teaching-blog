<?php
    if(isset($_POST["ok"])){
        include "../layout/database.php";
        $title = htmlspecialchars($_POST["title"]) ;
        $sql = "INSERT INTO category set title='$title'";
        $result = mysqli_query($connect,$sql);
        if($result){
            header("location:../category.php?information='Category Create Success'");
        }
    }
?>