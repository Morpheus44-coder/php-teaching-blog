<?php
    if(isset($_GET["id"])){
        include "../layout/database.php";
        $id = htmlspecialchars($_GET["id"]) ;
        $sql = "DELETE FROM admin WHERE id='$id'";
        $result = mysqli_query($connect,$sql);
        if($result){
            header("location:../account.php?information='Delete Account Success'");
        }else{
            header("location:../account.php?information='Delete Account Fail'");
        }
    }else{
        header("location:../index.php");
    }
?>