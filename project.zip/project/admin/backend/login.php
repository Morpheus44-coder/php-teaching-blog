<?php
    if(isset($_POST["login"])){
       include "../layout/database.php";
       $username = htmlspecialchars($_POST["username"]) ;
       $password = htmlspecialchars($_POST["password"]) ;
       $password = crypt($password,$username);
       $sql = "SELECT * FROM admin WHERE name='$username' AND password='$password'";
       $result = mysqli_query($connect,$sql);
       if(mysqli_num_rows($result)){
           session_start();
           $_SESSION["username"] = $username;
           $_SESSION["password"] = $password;
           header("location:../index.php");
       }else{
           header("location:../login.php?information='The Account Not Found'");
       }
    }else{
        header("location:../login.php");
    }
?>