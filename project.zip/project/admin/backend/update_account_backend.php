<?php
    
    if(isset($_POST["ok"])){
        include "../layout/database.php";
        $id = $_POST["id"];
        $username = $_POST["username"];
        $password = $_POST["password"];
        $confirmpassword = $_POST["cpassword"];
        // echo $id . $username . $password . $confirmpassword;
        if($password != $confirmpassword){
            header("location:../account.php?information=Password and Confirm Password is Not same");
        }else{
            $password = crypt($password,$username);
            $sql = "UPDATE admin SET name='$username',password='$password' WHERE id='$id'";
            $result = mysqli_query($connect,$sql);
            if($result){
                header("location:../account.php?information=Account Update Success");
            }else{
                header("location:../account.php?information=Account Update Fail");
            }
        }
    }else{
        header("location:../index.php");
    }
?>