<?php
    if(isset($_GET["id"])){
        include "../layout/database.php";
        $id = $_GET["id"];
        $sql = "DELETE FROM posts WHERE id='$id'";
        $result = mysqli_query($connect,$sql);
        if($result){
           header("location:../posts.php?information='Delete Post Success'");
        }
    }else{
        header("location:../posts.php");
    }
?>