<?php
    include "layout/header.php";
?>
<div class="container-fluid">
  <div class="row content">

    <?php
        include "layout/slide.php";
    ?>

    <div class="col-sm-9">
        <h3 class="text-center text-primary">Admin Account Lists</h3>
        <br>
                <?php
            if(isset($_GET['information'])){
                $info = $_GET['information'];
                ?>
                    <p class="alert alert-info"><?php echo $info ?></p>
                <?php
            }
        ?>
        <br>
        <ul class="breadcrumb">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="account.php">Account</a></li>
        </ul>
        <br>
        <a href="account_create.php" class="btn btn-success">Create Account</a>
        <br> <br>
        <table class="table table-hover">
      <thead>
        <tr>
          <th>No</th>
          <th>Username</th>
          <th>Update</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
      <?php
          $sql = "SELECT * FROM admin";
          $result = mysqli_query($connect,$sql);
          foreach($result as $i=>$r){
            ?>
            <tr>
              <td><?php echo ++$i; ?></td>
              <td><?php echo $r["name"] ?></td>
              <td><a href="backend/update_account.php?id=<?php echo $r['id'] ?>" class="btn btn-warning">Update</a></td>
              <td><a href="backend/delete_account.php?id=<?php echo $r['id'] ?>" class="btn btn-danger" >Delete</a></td>
            </tr>
            <?php
          }
      ?>

      </tbody>
    </table>
     </div>
  </div>  
</div>
<?php
    include "layout/footer.php";
?>

