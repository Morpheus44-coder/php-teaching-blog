<?php
    include "layout/header.php";
?>
<div class="container-fluid">
  <div class="row content">

    <?php
        include "layout/slide.php";
    ?>

    <div class="col-sm-9">
        <h3 class="text-center text-primary">Admin Category Create</h3>
        <br> <br>
        <ul class="breadcrumb">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="category.php">Category</a></li>
            <li><a href="category_create.php">Create Category</a></li>
        </ul>
        <br> 
        <?php
            if(isset($_GET['information'])){
                $info = $_GET['information'];
                ?>
                    <p class="alert alert-info"><?php echo $info ?></p>
                <?php
            }
        ?>
        <br>
       <form action="backend/actegory_backend.php" method="POST" class="form">
            <input type="text" class="form-control" name="title" placeholder="Enter Category Title" required> <br> 
            <input type="submit" class="btn btn-primary" value="Create" name="ok">
       </form>
    </div>
  </div>  
</div>
<?php
    include "layout/footer.php";
?>

