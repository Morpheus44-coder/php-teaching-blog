<?php
    include "layout/header.php";
?>
<div class="container-fluid">
  <div class="row content">

    <?php
        include "layout/slide.php";
    ?>

    <div class="col-sm-9">
        <ul class="breadcrumb">
            <li><a href="index.php">Dashboard</a></li>
        </ul>
     </div>
  </div>  
</div>
<?php
    include "layout/footer.php";
?>

