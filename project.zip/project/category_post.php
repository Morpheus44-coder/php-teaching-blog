<?php
    if(isset($_GET["id"])){
        $cat_id = $_GET["id"];
        ?>
        <?php
            include "client/header.php";
        ?>

        <?php
            include "client/nav.php";
        ?>
        
        <div class="container-fluid text-center">    
        <div class="row content">
        <?php
            include "client/left_slider.php";
        ?>
            <div class="col-sm-8 text-left"> 
            <?php
                $sql = "SELECT * FROM category WHERE id=$cat_id";
                $result = mysqli_query($connect,$sql);
                if($result){
                    foreach($result as $result){
                        ?>
                    <h1 class="text-center text-primary">The <?php echo $result["title"] ?> 's Posts </h1>
                    <?php
                        $title = $result["title"];
                        $sql = "SELECT * FROM posts WHERE category='$title' ORDER BY id DESC";
                        $data = mysqli_query($connect,$sql);
                        if($data){
                            foreach($data as $data){
                                $post_image = $data["image"];
                                $post_title = $data["title"];
                                $post_description = $data["description"];
                                ?>
                        <div class="media">
                            <div class="media-left">
                                <img src="admin/backend/upload/<?php echo $post_image ?>" class="media-object" style="width:60px">
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><?php echo $post_title ?></h4>
                                <p><?php echo $post_description ?></p>
                            </div>
                        </div>
                                <?php
                            }
                        }
                    ?>
                        <?php
                    }
                }
            ?>
            

            </div>
            <!-- right side bar -->
            <?php
                include "client/right_side_bar.php";
            ?>
        </div>
        </div>



        <?php
            include "client/footer.php";
        ?>
        <?php
    }else{
        header("location:index.php");
    }
?>