<?php
    include "client/header.php";
?>

<?php
    include "client/nav.php";
?>
  
<div class="container ">    
<?php
    $sql = "SELECT * FROM posts";
    $result = mysqli_query($connect,$sql);
    if($result){
        foreach($result as $r){
            $title = $r["title"];
            $category = $r["category"];
            $description = $r["description"];
            $description = substr($description,0,100);
            $image = $r["image"];
            $id = $r["id"];
           ?>
            <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <p style="height:60px"><?php echo $title ?></p>
                        <span class="badge"><?php echo $category ?></span></a><br>
                    </div>
                    <div class="panel-body">
                        <img src="admin/backend/upload/<?php echo $image ?>" class="img-reponsive img-thumbnail" style="height:200px" alt="">
                        <br> <br>
                        <p class="text-justify">
                            <?php
                                echo $description;
                            ?>  .....
                        </p>
                    </div>
                    <div class="panel-footer">
                        <a href="post_detail.php?id=<?php echo $id  ?>" class="btn btn-success btn-block">Read More</a>
                    </div>
                </div>
            </div>
           <?php
        }
    }
?>
</div>



<?php
    include "client/footer.php";
?>