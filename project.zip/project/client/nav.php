<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">KBTC</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li class="dropdown">
              <a data-toggle="dropdown">Category
              <span class="caret"></span></button>
              <ul class="dropdown-menu">
              <?php
                include "client/database.php";
                $sql = "SELECT * FROM category";
                $result = mysqli_query($connect,$sql);
                if($result){
                  foreach($result as $r){
                  ?>
                    <li><a href="category_post.php?id=<?php echo $r["id"] ?>"><?php echo $r["title"]  ?></a></li>
                  <?php
                   }
                }
              ?>
               
              </ul>
        </li>
        <li><a href="posts.php">Posts</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
       <li><a href="#">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>