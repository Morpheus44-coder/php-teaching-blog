    <div class="col-sm-2 sidenav">
    <h3>Category</h3>
<?php
    $sql = "SELECT * FROM category";
    $result = mysqli_query($connect,$sql);
    if($result){
        foreach($result as $r){
    ?>
        <p><a href="category_post.php?id=<?php echo $r["id"] ?>"><?php echo $r['title'] ?></a></p>
    <?php
        }
    }
    ?>    
    <hr>
    <h3>Latest Posts</h3>
<?php
    $sql = "SELECT * FROM posts ORDER BY id DESC LIMIT 5";
    $results = mysqli_query($connect,$sql);
    if($results){
        foreach($results as $rr){
            ?>
                <p><a href="#"><?php echo $rr['title'] ?></a></p>
            <?php
        }
    }
?>
    </div>