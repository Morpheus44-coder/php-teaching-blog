    <div class="col-sm-2 sidenav">
      <div class="well">
        <img src="image/ads.jpg" class="img-resposive img-thumbnail" alt="">
      </div>
      <div class="well">
         <img src="image/ads2.jpg" class="img-resposive img-thumbnail" alt="">
      </div>
    </div>